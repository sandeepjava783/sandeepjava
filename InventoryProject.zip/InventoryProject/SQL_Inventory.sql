/*
SQLyog - Free MySQL GUI v5.12
Host - 5.2.3-falcon-alpha-community-nt : Database - test
*********************************************************************
Server version : 5.2.3-falcon-alpha-community-nt
*/

SET NAMES utf8;

SET SQL_MODE='';

create database if not exists `test`;

USE `test`;

/*Table structure for table `inventory` */

DROP TABLE IF EXISTS `inventory`;

CREATE TABLE `inventory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemName` varchar(10) DEFAULT NULL,
  `cost` float DEFAULT NULL,
  `sell` float DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `profit` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `inventory` */

insert into `inventory` (`id`,`itemName`,`cost`,`sell`,`quantity`,`profit`) values (2,'xyz',10.55,12.55,1,8),(3,'pqr',10,15,5,25),(4,'abc',9.22,12.22,14,12.66);
