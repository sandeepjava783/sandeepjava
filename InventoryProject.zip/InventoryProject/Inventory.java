import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class Inventory 
{

	PreparedStatement pstmt=null;
	Connection con=null;
	ResultSet rs=null;
	public static void main(String[] args) 
	{
		Inventory obj = new Inventory();
		obj.conn();
		boolean status = true;
        do 
        {
            Scanner s = new Scanner(System.in);
            System.out.println("********************************************************************************************");
            System.out.println("Main Menu");
            System.out.println("1.create itemName costPrice sellingPrice");
            System.out.println("2.delete itemName");
            System.out.println("3.updateBuy itemName quantity");
            System.out.println("4.updateSell itemName quantity");
            System.out.println("5.report");
            System.out.println("6.updateSellPrice itemName newSellPrice");
            System.out.println("7.Exit System");
            System.out.println("*********************************************************************************************");
            System.out.println("Enter Operation Number : ");
            int a = s.nextInt();
            switch (a) 
            {
                case 1:
                		obj.create();
                    break;
                case 2:
                    	obj.deleteItem();
                    break;
                case 3:
                    	obj.updateBuy();
                    break;
                case 4:
                	obj.updateSell();
                    break;
                case 5:
                    obj.report();
                    break;
                    
                case 6:
                    obj.updateSellPrice();
                    break;
               
                case 7:
                    status = false;
                    break;
                default:
                	status = false;
            }
        } while (status);

	}
	public void conn()
	{
		try 
		{
				Class.forName("com.mysql.jdbc.Driver");
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root");
				System.out.println("DB Con Succes");
		}
		catch(Exception e)
		{
			System.out.println("Exception thrown : " + e);
		}
	}
	public void create()
	{
		try 
		{
			Scanner s = new Scanner(System.in);
			System.out.println("Enter Item Name : ");
			String itemName = s.next();
			System.out.println("Enter costPrice : ");
			float costPrice = s.nextFloat();
			System.out.println("Enter sellingPrice : ");
			float sellingPrice = s.nextFloat();
			
			pstmt = con.prepareStatement("insert into inventory(itemName,cost,sell,quantity,profit) values(?,?,?,?,?)");
			pstmt.setString(1,itemName);
			pstmt.setFloat(2,costPrice);
			pstmt.setFloat(3,sellingPrice);
			pstmt.setInt(4,0);
			pstmt.setFloat(5,0);
			int i = pstmt.executeUpdate();
			if(i>0)
			{
				System.out.println("Item Added.");
			}
			else
			{
				System.out.println("Item is not Added.");
			}
		}
		catch(Exception e)
		{
			System.out.println("Exception thrown : " + e);
		}
	}
	public void deleteItem()
	{
		try 
		{
			Scanner s = new Scanner(System.in);
			System.out.println("Enter Item Name to Deleted : ");
			String itemName = s.next();
			
			pstmt = con.prepareStatement("delete from inventory where itemName=?");
			pstmt.setString(1,itemName);
			
			int i = pstmt.executeUpdate();
			if(i>0)
			{
				System.out.println("Item Deleted.");
			}
			else
			{
				System.out.println("Item is not Available to Deleted.");
			}
		}
		catch(Exception e)
		{
			System.out.println("Exception thrown : " + e);
		}
	}
	public void updateBuy()
	{
		try 
		{
			Scanner s = new Scanner(System.in);
			System.out.println("Enter Item Name to updateBuy : ");
			String itemName = s.next();
			System.out.println("Enter purchases Quantity : ");
			int quantity = s.nextInt();
			pstmt = con.prepareStatement("update inventory set quantity=? where itemName=?");
			pstmt.setInt(1,quantity);
			pstmt.setString(2,itemName);
			
			int i = pstmt.executeUpdate();
			if(i>0)
			{
				System.out.println("updateBuy Updated.");
			}
			else
			{
				System.out.println("ItemName Not Exist.Enter Correct ItemName.");
			}
		}
		catch(Exception e)
		{
			System.out.println("Exception thrown : " + e);
		}
	}
	public void updateSell()
	{
		showItem();
		try 
		{
			
			Scanner s = new Scanner(System.in);
			System.out.println("Enter Item Name to updateSell : ");
			String itemName = s.next();
			System.out.println("Enter Sell Quantity : ");
			int quantity = s.nextInt();
			
			String queryString = "select itemName,cost,sell,quantity,profit from inventory where itemName='"+itemName+"'";
			Statement stmt = con.createStatement();
		    rs = stmt.executeQuery(queryString);
		    
		    int dbQuantity=0;
		    float cost_Price=0f,sell_Price=0f,db_profit=0f;
		    boolean status=true;
		    if(rs.next())
		    {
		    	cost_Price = rs.getFloat("cost");
		    	sell_Price = rs.getFloat("sell");
		    	dbQuantity=rs.getInt("quantity");
		    	db_profit = rs.getFloat("profit");
		    	status=true;
		    }
		    else
		    {
		    	status=false;
		    	System.out.println("ItemName Not Exist.Enter Correct ItemName.");
		    }
		    if(status)
		    {
		    	if(dbQuantity<quantity)
		    	{
		    		System.out.println("Item quantity is less available than your Sell Quantity.");
		    	}
		    	else
		    	{
		    		int qty = dbQuantity-quantity;
		    		float final_cost = sell_Price-cost_Price;
		    		float total = final_cost*quantity;
		    		float profit=db_profit+total ;
			    	pstmt = con.prepareStatement("update inventory set quantity=?,profit=? where itemName=?");
					pstmt.setInt(1,qty);
					pstmt.setFloat(2,profit);
					pstmt.setString(3,itemName);
					
					int i = pstmt.executeUpdate();
					if(i>0)
					{
						System.out.println("updateSell Updated.");
						showItem();
					}
		    	}
		    }
		}
		catch(Exception e)
		{
			System.out.println("Exception thrown : " + e);
		}
	}
	public void report()
	{
		try 
		{
			String queryString = "select itemName,cost,sell,quantity,profit from inventory order by itemName";
			Statement stmt = con.createStatement();
		    rs = stmt.executeQuery(queryString);
		    
			System.out.println("");
			System.out.println("            INVENTORY REPORT");
			System.out.println("Item Name\tBought At\tSold At  AvailableQty\tValue");
			System.out.println("----------\t---------\t-------\t----------\t------");
			float total=0f;
			float profit=0f;
			while(rs.next())
		    {
		    	String item_name=rs.getString("itemName");
		    	float cost=rs.getFloat("cost");
		    	float sell=rs.getFloat("sell");
		    	int quantity=rs.getInt("quantity");
		    	float subtotal = cost*quantity;
		    	profit+=rs.getFloat("profit");
		    	total+=subtotal;
		    	System.out.println(item_name+ "\t\t"+cost+ "\t\t"+sell+ "\t\t"+quantity+ "\t"+subtotal);
		    }
			System.out.println("---------------------------------------------------------------------------");
			System.out.println("Total value\t\t\t\t\t\t"+total);
			System.out.println("Profit since previous report\t\t\t\t"+profit);                                     
		}
		catch(Exception e)
		{
			
		}
	}
	
	public void showItem()
	{
		try 
		{
			String queryString = "select itemName,quantity from inventory ";
			Statement stmt = con.createStatement();
		    rs = stmt.executeQuery(queryString);
		   
		    System.out.println("---------------------------------");
		    System.out.println("ItemName | Available Quantity ");
		    System.out.println("---------------------------------");
		    while(rs.next())
		    {
		    	String item_name=rs.getString("itemName");
		    	int dbQuantity=rs.getInt("quantity");
		    	 System.out.println(item_name+ " | \t "+dbQuantity);
		    }
		    System.out.println("---------------------------------");
		    System.out.println();
		}
		catch(Exception e)
		{
			System.out.println("Exception thrown : " + e);
		}
	}
	public void updateSellPrice()
	{
		try 
		{
			Scanner s = new Scanner(System.in);
			System.out.println("Enter Item Name to updateSellPrice : ");
			String itemName = s.next();
			System.out.println("Enter new SellPrice : ");
			float sellPrice = s.nextFloat();
			pstmt = con.prepareStatement("update inventory set sell=? where itemName=?");
			pstmt.setFloat(1,sellPrice);
			pstmt.setString(2,itemName);
			
			int i = pstmt.executeUpdate();
			if(i>0)
			{
				System.out.println("update SellPrice Successfully.");
			}
			else
			{
				System.out.println("ItemName Not Exist.Enter Correct ItemName.");
			}
		}
		catch(Exception e)
		{
			System.out.println("Exception thrown : " + e);
		}
	}
}
